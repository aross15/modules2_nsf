Here is what the filenames mean for paired data:
The first thing after "paired-" is one of:
 "f" for female students,
 "m" for male students,
 "all" for all students.
Filtering by student type is done first, then we take the mean score for each class (small, regular, or regular+aide).
Later, we might add filters like "fl" for free-lunch or "nonfl" for non-free-lunch.
Filtering on some characteristics might produce 0 students in some classes, though. For example, some classes might have no students of a particular race.

The next thing in the filename is either:
 "s" for a Small-versus-Regular comparison, or
 "a" for an Aide-versus-Regular comparison.

Column names in the file that have an .SA in them are either for Small or Aide classes, depending on the filename.

Each file has a .csv version and a .txt version. This is because browsers tend to automatically download .csv files,
while they display .txt files in a tab.
So if you want to copy-paste the data into Lock5stat.com/StatKey applets, the .txt files are better.
However, if you copy-paste data into the Edit Data tab, it has to have only 1 or 2 columns, not many columns.
So, we have files that have just 2 columns in them, called "2col", rather than all columns, called "full".

In general, it's nicer to upload a file, because then you can use the full data set, then pick which columns you want after you upload.

Example filenames are:
tn-star-paired-all-a-2col.csv
tn-star-paired-all-a-full.csv
tn-star-paired-all-s-2col.csv
tn-star-paired-all-s-full.csv
tn-star-paired-f-a-2col.csv
tn-star-paired-f-a-full.csv
tn-star-paired-f-s-2col.csv
tn-star-paired-f-s-full.csv
tn-star-paired-m-a-2col.csv
tn-star-paired-m-a-full.csv
tn-star-paired-m-s-2col.csv
tn-star-paired-m-s-full.csv
