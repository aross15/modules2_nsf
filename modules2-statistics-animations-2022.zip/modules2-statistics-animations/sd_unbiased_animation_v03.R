# create an animation that shows why dividing by n-1 is better than dividing by n
# when computing the Standard Deviation.

# first, modify the stripchart function a little
# so we can pass it 2 sets of x values, one rounded to cause coincidences and stacking,
# and another of the original x values to use when plotting.
# Based on code from 
# https://raw.githubusercontent.com/SurajGupta/r-source/master/src/library/graphics/R/stripchart.R

#  File src/library/graphics/R/stripchart.R
#  Part of the R package, https://www.R-project.org
#
#  Copyright (C) 1995-2015 The R Core Team
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  A copy of the GNU General Public License is available at
#  https://www.R-project.org/Licenses/

## Dotplots a la Box, Hunter and Hunter

mystripchart <- function(x, ...) UseMethod("mystripchart")

mystripchart.default <-
  function(x, method = "overplot", jitter = 0.1, offset = 1/3, vertical = FALSE,
           group.names, add = FALSE, at = NULL,
           xlim = NULL, ylim = NULL, ylab = NULL, xlab = NULL,
           dlab = "", glab = "", log = "", pch = 0, col = par("fg"),
           cex = par("cex"), axes = TRUE, frame.plot = axes, origx=x, ...)
  {
    method <- pmatch(method, c("overplot", "jitter", "stack"))[1L]
    if(is.na(method) || method == 0L)
      stop("invalid plotting method")
    groups <-
      if(is.list(x)) x else if(is.numeric(x)) list(x)
    n <- length(groups)
    if(!n) stop("invalid first argument")
    if(!missing(group.names))
      attr(groups, "names") <- group.names
    else if(is.null(attr(groups, "names")))
      attr(groups, "names") <- seq_len(n)
    if(is.null(at)) at <- seq_len(n)
    else if(length(at) != n)
      stop(gettextf("'at' must have length equal to the number %d of groups",
                    n), domain = NA)
    if (is.null(dlab)) dlab <- deparse(substitute(x))
    
    dev.hold(); on.exit(dev.flush())
    if(!add) {
      dlim <- range(unlist(groups, use.names = FALSE), na.rm = TRUE)
      glim <- c(1L, n) # in any case, not range(at)
      if(method == 2L) { # jitter
        glim <- glim + jitter * if(n == 1) c(-5, 5) else c(-2, 2)
      } else if(method == 3) { # stack
        glim <- glim + if(n == 1L) c(-1,1) else c(0, 0.5)
      }
      if(is.null(xlim))
        xlim <- if(vertical) glim else dlim
      if(is.null(ylim))
        ylim <- if(vertical) dlim else glim
      plot.new()
      plot.window(xlim, ylim, log, ...)
      if(frame.plot) box() # maybe (...)
      if(vertical) {
        if (axes) {
          if(n > 1L) axis(1, at = at, labels = names(groups), ...)
          Axis(origx, side = 2, ...)
        }
        if (is.null(ylab)) ylab <- dlab
        if (is.null(xlab)) xlab <- glab
      }
      else {
        if (axes) {
          Axis(origx, side = 1, ...)
          if(n > 1L) axis(2, at = at, labels = names(groups), ...)
        }
        if (is.null(xlab)) xlab <- dlab
        if (is.null(ylab)) ylab <- glab
      }
      title(xlab = xlab, ylab = ylab, ...)
    }
    csize <- cex *
      if(vertical) xinch(par("cin")[1L]) else yinch(par("cin")[2L])
    for(i in seq_len(n)) {
      x <- groups[[i]]
      y <- rep.int(at[i], length(x))
      if(method == 2L) ## jitter
        y <- y + stats::runif(length(y), -jitter, jitter)
      else if(method == 3L) { ## stack
        oldway <- F
        if(oldway){
        xg <- split(x, factor(x))
        xo <- lapply(xg, seq_along)
        x <- unlist(xg, use.names=FALSE)
        y <- rep.int(at[i], length(x)) +
          (unlist(xo, use.names=FALSE) - 1) * offset * csize
        }else{# do it the brute-force way,
          # which preserves the order of the x values, so it matches
          # the order of the origx values, if any.
          y <- vector(length=length(x)) #allocate some space
          for(nn in 1:length(x)){
            # count how many entries from 1 to now (nn) are equal to the
            # current value
            y[nn]=at[i]+(sum(x[1:nn]==x[nn])) *offset*csize
          }
        }
      }
      if(vertical)
        points(y, origx, col = col[(i - 1L) %% length(col) + 1L],
               pch = pch[(i - 1L) %% length(pch) + 1L], cex = cex, ...)
      else
        points(origx, y, col = col[(i - 1L) %% length(col) + 1L],
               pch = pch[(i - 1L) %% length(pch) + 1L], cex = cex, ...)
    }
    df<-data.frame(x,origx,y) # hand back these hard-won y values
    invisible(df)
  }

mystripchart.formula <-
  function(x, data = NULL, dlab = NULL, ..., subset, na.action = NULL)
  {
    if(missing(x) || (length(x) != 3L))
      stop("formula missing or incorrect")
    m <- match.call(expand.dots = FALSE)
    if(is.matrix(eval(m$data, parent.frame())))
      m$data <- as.data.frame(data)
    m$... <- NULL
    m$formula <- m$x
    m$x <- NULL
    m$na.action <- na.action # force use of default for this method
    ## need stats:: for non-standard evaluation
    m[[1L]] <- quote(stats::model.frame)
    mf <- eval(m, parent.frame())
    response <- attr(attr(mf, "terms"), "response")
    if (is.null(dlab)) dlab <- names(mf)[response]
    mystripchart(split(mf[[response]], mf[-response]), dlab = dlab, ...)
  }
##############################################################################
##############################################################################
##############################################################################

# Generate some heart-rate-per-minute data:
set.seed(2018)
sampsize <- 5
popsize <- 29 # don't want any numeric coincidences like: 
#popsize/sampsize=integer or popsize/(sampsize-1)=integer
# since students might latch on to them even though they would be meaningless.
# Or would it be better to have such coincidences, and let students work out themselves that the coincidences are meaningless?

targetmean <- 80
targetsd <- 10

wholeclass <- round(rnorm(n=popsize,mean=targetmean,sd=targetsd))
# first, compute the mean and SD for the population:
popmean <- mean(wholeclass)
# the sd() function divides by n-1, 
# so we apply a correction factor of sqrt((n-1)/n) to get the denominator to be n.
popsd <- sd(wholeclass) * sqrt((popsize-1)/popsize)

# We want an integer mean, for simplicity, and an SD very close to the target.
# and all-integer data. It's hard to manipulate data by hand to do that,
# and even using Solver in Excel it's hard to get good numbers,
# so we'll try it randomly!
ntry <- 100000

ntry <- 1 #shortcut this whole process since we've already done it and found a good seed/data set:
# seed 60043
# data: 75  77  78  71  69  91  72  90  81  87 102  76  71  93  84  89  59  82  96  77  81  67  81  70  76  66  93  90  76
# or,
# wholeclass<-c(75,77,78,71,69,91,72,90,81,87,102,76,71,93,84,89,59,82,96,77,81,67,81,70,76,66,93,90,76)

results <- matrix(NA,nrow=ntry,ncol=4)
for( thisseed in 1:ntry){
  set.seed(thisseed)
  wholeclass <- round(rnorm(n=popsize,mean=targetmean,sd=targetsd))
  # first, compute the mean and SD for the population:
  popmean <- mean(wholeclass)
  # the sd() function divides by n-1, 
  # so we apply a correction factor of sqrt((n-1)/n) to get the denominator to be n.
  popsd <- sd(wholeclass) * sqrt((popsize-1)/popsize)
  results[thisseed,1] <- thisseed
  results[thisseed,2] <- popmean
  results[thisseed,3] <- popsd
  results[thisseed,4] <- sd(table(wholeclass))
  # we would like a dotplot with a fair amount of stacking rather than none,
  # so we "table" the data to get frequencies, then compute the SD of those
  # frequencies. Larger SD = some stacks, some non-stacks
}  
intmean <- results[,2]==floor(results[,2]) # a list of which rows have integer mean
intresults <- results[intmean,]
# since we probably don't have an SD exactly equal to the target,
# just select the SDs that are slightly above the target, since students
# will find it easier to accept rounding 10.01 to 10 than rounding 9.99 to 10.
fewerresults <- intresults[intresults[,3]>=targetsd,]
bestrow <- which.min(abs(fewerresults[,3] - targetsd ))
fewerresults[bestrow,] # shows the seed, the mean, the SD
# or, get just those that have exactly the right SD:

fewerresults<-intresults[intresults[,3]==targetsd,]

# good seeds at popsize=29:
#  5679 (but not much stacking)
# 60043 (the best)
# 93624 (not so good, since a 2-stack at max value)

# now recreate the data using that seed:
bestrow <- 2
#set.seed(fewerresults[bestrow,1])
set.seed(60043)
wholeclass <- round(rnorm(n=popsize,mean=targetmean,sd=targetsd))

# compute the mean and SD for the population:
popmean <- mean(wholeclass)
# the sd() function divides by n-1, 
# so we apply a correction factor of sqrt((n-1)/n) to get the denominator to be n.
popsd <- sd(wholeclass) * sqrt((popsize-1)/popsize)
# and shift everything to have the target mean 
# (shift mean down to 0 then up to target):
wholeclass <- wholeclass - popmean + targetmean
# would like it to have longer tail to the right than the left
# since high heart rates are more believable than super-low heart rates.
# so if it doesn't, flip it left-right around the mean.
if( mean(wholeclass) < median(wholeclass)){
  wholeclass <- targetmean + (targetmean-wholeclass)
}

# or could just do this:
wholeclass<-c(75,77,78,71,69,91,72,90,81,87,102,76,71,93,84,89,59,82,96,77,81,67,81,70,76,66,93,90,76)

popmean <- mean(wholeclass)
popsd <- sd(wholeclass) * sqrt((popsize-1)/popsize)

#####################################################
# now make the movie

nframes <- 100
justplotlast <- F # useful when debugging

sdvalsN <- vector()
sdvalsN1 <- vector()
seedmult <- 15 # choose a different seedmult to get a different run of the animation
# make a plot with the population and a sample
for( framenum in 1:nframes){
  # first do the calculations, then the plots,
  # so if we're just plotting the last we can skip the plots.
  
  set.seed(framenum*seedmult)
  samp <- sample(wholeclass,size=sampsize,replace=F)
  smean <- mean(samp)
  # the sd() function divides by n-1, 
  # so we apply a correction factor of sqrt((n-1)/n) to get the denominator to be n.
  sdN1 <- sd(samp)
  sdN <-  sd(samp) * sqrt((sampsize-1)/sampsize)
  # record the new SD estimates
  sdvalsN  <- c(sdvalsN ,sdN )
  sdvalsN1 <- c(sdvalsN1,sdN1)
  
  if( !justplotlast | framenum==nframes ){  
    # got idea from https://www.r-bloggers.com/animated-plots-with-r/
    fname <- sprintf("sd_unbiased_anim_frame%04d.png",framenum)
    #saves the plot as a .png file in the working directory
    png(fname)
    
    par(mfrow=c(1,2),
        mar=c(5,0.1,0.1,0.1), oma=c(0,0,0,0)
        ) # 2 columns, one for the pop&sample plots, one for the dotplots of the SD values
    
    stripchart(wholeclass,method="stack",col="grey",ylim=c(0,4),at=3,xlab="Individual values")
    par(family="mono") # do this here so it applies to all later text commands
    
    # add a vertical bar or arrow showing the mean and a horizontal bar showing mean+1*SD
    yval1 <- 2.5
    yval2 <- 2.8
    arrows(popmean,yval1,popmean,yval2,col="grey",length=0.1)
    arrows(popmean,yval2,popmean+1*popsd,yval2,col="grey",length=0.1)
    # add a vertical bar at the end of the arrow to give the sense of stopping there,
    # rather than continuing on to the right where the arrow is pointing.
    # Doing this the easy way: drawing an arrow whose barbs are at 90 degrees!
    # Adjusting the length so they are the same vertical height as the original
    # 30-degree barbs.
    arrows(popmean,yval2,popmean+1*popsd,yval2,col="grey",length=0.1/2,angle=90)
    
    # Add text to show the pop SD:
    text(popmean+0.3*popsd,yval1,labels=sprintf("%4.1f=Pop SD",popsd),col="grey",pos=4)
    # Add text to say Population:
    text(popmean,yval2+1,"Population",col="grey")
    
    ####################### now deal with the sample
    
    yval0 <- 0.1
    yval1 <- 0.4
    yval2 <- 0.7
    yval3 <- 0.8
    
    # dotplot the sample:
    stripchart(samp,method="stack",col="black",add=T, at=1)
    # Add text to say Sample:
    text(popmean,yval2+1,"Sample",col="black")
    
    # add a vertical bar or arrow showing the mean and a horizontal bar showing mean+1*SD
    yval0 <- 0.1
    yval1 <- 0.4
    yval2 <- 0.7
    yval3 <- 0.8
    arrows(smean,yval1,smean,yval2,col="black",length=0.1) # vertical arrow for the mean
    # graphing the SD arrows in the same vertical order as the text labels:
    #using n above, using n-1 below.
    # yval2 is below, yval3 is above.
    # graph the SD when dividing by n, above
    arrows(smean,yval3,smean+1*sdN,yval3,col="black",length=0.1)
    arrows(smean,yval3,smean+1*sdN,yval3,col="black",length=0.1/2,angle=90)
    # graph the SD using n-1, below
    arrows(smean,yval2,smean+1*sdN1,yval2,col="green",length=0.1)
    arrows(smean,yval2,smean+1*sdN1,yval2,col="green",length=0.1/2,angle=90)
    
    
    # Add text to show the sample SDs.
    # We want to be able to read them, so we don't want them jumping around
    # from sample to sample/frame to frame. 
    # So, deliberately putting them at x=POPmean+POPsd, 
    # rather than using the sample SD.
    # color-code the text: red if under the true pop sd, blue if above.
    # Avoiding red-vs-green distinctions since the most common form of
    # color blindness is red/green.
    if( sdN < popsd ){
      mycol <- "red"
    }else{
      mycol <- "blue"
    }
    text(popmean+0.0*popsd,yval1,labels=sprintf("%4.1f using n",sdN),col=mycol,pos=4)
    if( sdN1 < popsd ){
      mycol <- "red"
    }else{
      mycol <- "blue"
    }
    text(popmean+0.0*popsd,yval0,labels=sprintf("%4.1f using n-1",sdN1),col=mycol,pos=4)
    
    
    # and make the dotplots that record the SDs.
    #using n above, using n-1 below.
    
    myxlim <- c(0,25)
    myylim <- c(0,3)
    
    # make the plot height shrink as the #datapoints grows
    myoffset <- (1/3)/(framenum/40)
    
    rd <- 0 # rounding level, just for getting good stacks
    mystripchart(round(sdvalsN ,rd),method="stack",col="black",add=F, at=2,xlim=myxlim,ylim=myylim,pch=1,xlab="SD estimate",offset=myoffset,origx=sdvalsN)
    mystripchart(round(sdvalsN1,rd),method="stack",col="green",add=T, at=1,xlim=myxlim,ylim=myylim,pch=1,offset=myoffset,origx=sdvalsN1)
    # show the means of these sampling distributions of the SD estimates
    arrows(mean(sdvalsN ),2-0.3,mean(sdvalsN ),2-0.1,col="black",length=0.1) # vertical arrow for the mean
    arrows(mean(sdvalsN1),1-0.3,mean(sdvalsN1),1-0.1,col="green",length=0.1) # vertical arrow for the mean
    # say which one is which 
    text(popsd*1.25,2-0.1,labels="using n",col="black",pos=4)
    text(popsd*1.25,1-0.1,labels="using n-1",col="green",pos=4)
    
    # and plot the true PopSD as a vertical line
    abline(v=popsd,col="grey")
    # Add text to say Population:
    text(popsd,0.1,"Pop.SD",col="grey")
    
    # output the plot
    dev.off()
    #...
  } # end if justplotlast
} # end for loop


# from: https://www.r-bloggers.com/animated-plots-with-r/
# then run this from a Unix- or Windows-like command line:
# convert *.png -delay 3 -loop 0 binom.gif
# or in our case
# convert sd_unbiased_anim_frame*.png -delay 20 -loop 0 sd_unbiased_anim.gif
# according to https://www.imagemagick.org/discourse-server/viewtopic.php?t=14739
# the delay value is 1/100ths of a second, so frame rate is 100/delay
# I'm trying delay of 20
