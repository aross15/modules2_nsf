# Create an animation of the Catherine Case / Tim Jacobbe inference framework.
# by Andrew Ross, Eastern Michigan University, Ypsilanti, MI
# License: Creative Commons Attribution-ShareAlike 3.0 Unported License,
# just like the MODULE(S^2) project modules.
# The Mathematics Of Doing, Understand, Learning, and Educating for Secondary Schools (MODULES) project is partially supported by funding from a collaborative grant of the National Science Foundation under Grant Nos. DUE-1726707, 1726804, 1726252, 1726723, 1726744, and 1726098.  Any opinions, findings, and conclusions or recommendations expressed in this material are those of the authors and do not necessarily reflect the views of the National Science Foundation.

# based on the framework shown in:
#A Framework to Characterize Student Difficulties in Learning Inference from a Simulationed-Based Approach
#Catherine Case and Tim Jacobbe
#Statistics Education Research Journal
#ISSN: 1570-1824
#Volume 17 Number 2, November 2018
# https://iase-web.org/documents/SERJ/SERJ17(2)_Case.pdf

# was trying to find the name of the currently running script, so we
# could copy it somewhere automatically. Never ended up working.
#https://support.rstudio.com/hc/en-us/community/posts/206540097-Obtain-full-filename-of-the-Rscript
cA=commandArgs(trailingOnly = FALSE)
script.name <- basename(strsplit(commandArgs(trailingOnly = FALSE)[4],"=")[[1]][2])



#https://github.com/stefano-meschiari/latex2exp
#install.packages("latex2exp")
library("latex2exp")

sampseed = 7 # if sampseed < 1000 , won't get added to the "mymethod" identifier, for simplicity.
# 7 gave a p.1sided of 0.072; might want it to be a little larger
sampseed = -1 # if sampseed < 1000 , won't get added to the "mymethod" identifier, for simplicity.
sampseed = 1000

mymethod = "ht1m" # hypothesis test for 1 mean; this goes into filenames,
# so different animations can have their files in the same folder.
do.CI = FALSE

mymethod = "ci1m" # confidence interval for 1 mean; this goes into filenames,
# so different animations can have their files in the same folder.
do.CI = TRUE
confidence = 0.95



if( sampseed >= 1000) {
  mymethod=sprintf("%s%d",mymethod,sampseed)  
}


# we want to specify color names and not have them turn into factors in dataframes:
options(stringsAsFactors = FALSE)

# set up some lists to store HTML that render() generates
htmli = list() # for the index/table-of-contents we'll be making
htmlb = list() # for the body of the html document

# where does each box (R1,R2,R3,H1,H2,H3) go in the [0,1]-by-[0.1] frame?
rxmin=0.01
rxmax=0.49
hxmin=0.51
hxmax=0.99
l1min=0.67
l1max=0.99
l2min=0.34
l2max=0.66
l3min=0.01
l3max=0.33

rxmin=0.05
rxmax=0.45
hxmin=0.55
hxmax=0.95
l1min=0.7
l1max=0.95 # was 0.9 but ...
l2min=0.4
l2max=0.58 # was 0.6 but needs a tad more room
l3min=0.1
l3max=0.28 # was 0.3 but needs a tad more room
######################
# make the coordinates for the thought bubble.
# I did a screenshot of the thought bubble in the Case/Jacobbe article,
# erased the non-bubble parts in MS Paint,
# uploaded the picture to Desmos,
# used a Table and typed in (x,y) coordinates by hand so they were
# (by eye) the centers of the various circle segments that
# make up the thought bubble edges,
# then typed in an approximate radius for each one (again judging by eye).

# https://www.desmos.com/calculator/lqtcje3pqv
xcenters=c(.313,.32,.35,.52,.75,.85,.86,.77,.61,.44,.27,.12,.14,.30)

# actually want to move the first 3 bubbles a bit to the left:
xcenters=c(.12,.13,.16,.52,.75,.85,.86,.77,.61,.44,.27,.12,.14,.30)
ycenters=c(.13,.15,.2,.4,.375,.5,.625,.68,.7,.67,.6,.51,.39,.38)
radius=c(.02,.035,.05,.19,.1,.12,.1,.11,.09,.11,.14,.08,.08,.15)

# We will generate points on the full circumference of each of the circles,
# then erase the points that fall too close to the middle of the bubble,
# by defining some elliptical regions in the middle.

circlepoints<-function(xc,yc,r){
  theta<-seq(0,2*pi,by=2*pi/360)
  df<-data.frame(x=xc+r*cos(theta),y=yc+r*sin(theta))
}

df <- data.frame()
for(nn in 1:length(xcenters)){
  tmp<-circlepoints(xcenters[nn],ycenters[nn],radius[nn])
  df <- rbind(df,tmp)
}
# now exclude some points to make room in the middle.
#ee =  ellipses that exclude other points
ee<-data.frame(xc=0.55,yc=0.5,a=0.42,b=0.2,degrees=20)
ee<-rbind(ee,data.frame(xc=0.41,yc=0.5,a=0.32,b=0.2,degrees=0))
for( nn in 1:nrow(ee)){
  x=df$x - ee$xc[nn]
  y=df$y - ee$yc[nn]
  a=ee$degrees[nn]*2*pi/360
  si=sin(a)
  co=cos(a)
  # equation of a tilted ellipse:
  # https://www.maa.org/external_archive/joma/Volume8/Kalman/General.html
  # (x*co+y*si)^2/a^2 + (x*si-y*co)^2/b^2 = 1^2
  # so if the left-hand side is < 1, the point is inside the ellipse.
  adj.r=((x*co+y*si)/ee$a[nn])^2+((x*si-y*co)/ee$b[nn])^2
  del.these=adj.r < 1 
  df=df[!del.these,]
}
#plot(df$x,df$y,pch='.')
# pch=46 is the same as pch='.' ; we need to use an integer so we don't
# make the pch data frame column change types from integer to character.
orig.bubble.pdf <- data.frame(x=df$x,y=df$y,pch=46,col="darkgrey",cex=1)
# still need to scale it to fit the R3 cell; will do that later.


######################
mu0 = 7 # null hypothesis mean
# don't need mu0 for a CI animation but doesn't hurt to leave it here.

# make up some population data
set.seed(2019)
popsize <- 100
targetmean <- 6.5 # for example, about 6 hours of sleep per night
targetsd <- 1

# choose a common x axis range.
# Part of the whole point of this is to have all graphs use
# the same x axis range--lock5stat doesn't do that,
# and the Agresti and Franklin and Klingenberg applets don't.
# Chris Wild's graph does, though:
# https://www.stat.auckland.ac.nz/~wild/ISR-15/anim/BS_cf_Samp_Mean-SNIPPET_50.gif
popxlim <- c(0,12) #will use this common xlim range for all 6 plots

popxlim <- c(3,11) #will use this common xlim range for all 6 plots
# though there's some danger than when shifting data to have mean=mu0,
# some x values might go outside the range. So, keep the range reasonably large.

popdata <- rnorm(n=popsize,mean=targetmean,sd=targetsd)
# first, compute the mean and SD for the population:
popmean <- mean(popdata)
# the sd() function divides by n-1, 
# so we apply a correction factor of sqrt((n-1)/n) to get the denominator to be n.
popsd <- sd(popdata) * sqrt((popsize-1)/popsize)

# check that popxlim will include all data, for real-world and null-hyp.
if( max(popdata) > max(popxlim)){
  warning("max(popxlim) not large enough for pop data")
}
if( min(popdata) < min(popxlim)){
  warning("min(popxlim) not small enough for pop data")
}
if( max(popdata)-popmean+mu0 > max(popxlim)){
  warning("max(popxlim) not large enough after shifting for null hyp.")
}
if( min(popdata)-popmean+mu0 < min(popxlim)){
  warning("min(popxlim) not small enough after shifting for null hyp.")
}

# it will be handy to have it rounded to the nearest 0.1 for dot-plotting.
rounddigits = 1
popdata.1 <- round(popdata,digits=rounddigits)
##########################
dotplot.coord <- function(xdata.rounded,xdata.orig){
  # sort of mimicking stripchart()
  # do it the brute-force way, O(n^2)
  # which preserves the order of the x values, so it matches
  # the order of the origx values, if any.
  y <- vector(length=length(xdata.rounded)) #allocate some space
  for(nn in 1:length(xdata.rounded)){
    # count how many entries from 1 to now (nn) are equal to the
    # current value
    y[nn]=(sum(xdata.rounded[1:nn]==xdata.rounded[nn]))
  }
  # return a data frame? but that renames the x values from what was passed in.
  #df=data.frame(xdata.rounded, xdata.orig, y)
  y # just return the y values
}
#df=dotplot.coord(popdata.1,popdata)
#plot(df$xdata.orig, df$y)
popy=dotplot.coord(popdata.1,popdata)
#plot(popdata, popy)

##########################
##########################

render <- function(pointdf, textdf=NULL, segmentdf=NULL, arrowdf=NULL,edf=NULL,mymain=NULL,fprefix="a",framenum=-1,writefile=T,main.expr=NULL){
  # edf is "expression df", like textdf but has expression()s in it,
  # usually involving mu_0 or xbar.
  # This is so textdf's "label" column can be all character-strings,
  # and edf's "label" column can be all expressions,
  # rather that trying to mix them in 1 column.
  
  #plot in this order: pointdf, textdf, edf, segmentdf, then arrowdf
  # so arrows show up on top of everything.
  fname=sprintf("framework_%s_frame_%s%04d.png",mymethod,fprefix,framenum)
  if( writefile ){
    #saves the plot as a .png file in the working directory
    png(fname)
  }
  
  # write the HTML code,
  # but skip frame prefix "c" because those are the rapid frames,
  # and there are so many of them we don't want them in the html file.
  if( fprefix != "c"){
    tmp=c(unlist(htmli),sprintf("<li><a href=\"#%s\">%s</a>",fname,mymain))
    assign("htmli", tmp, envir = .GlobalEnv)
    tmp=c(unlist(htmlb),sprintf("<h3><a id=\"%s\">%s</a></h3>",fname,mymain),
          sprintf("<img src=\"%s\" alt=\"%s\">",fname,mymain))
    assign("htmlb", tmp, envir = .GlobalEnv)
  }
  
  # look for things that we'd like to turn into math notation: mu, mu0, xbar
  # (both in the title text, mymain, and in the textdf)
  
  if( is.null(main.expr)){
    # if no R "expression" was passed in as an alternate to the "mymain"
    # graph title, just use "mymain" as the title.
    #main.expr=mymain
    # Actually it helps to TeX it, so it's always non-bolded
    main.expr=TeX(mymain)
  }
  
  # First, set up a blank plot
  plot(1, type="n", xlab="", ylab="", xlim=c(0, 1), ylim=c(0, 1),axes=F,main=main.expr)
  points(pointdf$x,pointdf$y,col=pointdf$col,pch=pointdf$pch,cex=pointdf$cex)
  if( !is.null(textdf) ){
    # apply TeX to each label to turn it into an expression
    tmp=list()
    for( nn in 1:nrow(textdf)){
      tmp=c(tmp,TeX(textdf$label[nn]))
    }
    
    text(textdf$x,textdf$y,label=tmp,pos=textdf$pos,col=textdf$col)
  }
  if( !is.null(edf) ){
    text(edf$x,edf$y,edf$label,pos=edf$pos,col=edf$col)
  }
  if( !is.null(segmentdf) ){
    segments(segmentdf$x0,segmentdf$y0,segmentdf$x1,segmentdf$y1,col=segmentdf$col,lty=segmentdf$lty,lwd=segmentdf$lwd)
  }
  if( !is.null(arrowdf) ){
    arrows(arrowdf$x0,arrowdf$y0,arrowdf$x1,arrowdf$y1,length=arrowdf$length,col=arrowdf$col,lty=arrowdf$lty,lwd=arrowdf$lwd)
  }
  if( writefile ){
    # output the plot
    dev.off()
  }
}
#############
mapto <- function(vals, pseudovals,omin, omax){
  # pseudovals affects the observed min & max of vals,
  # but then don't get returned.
  # This helps keep consistent x limits on axes, for example.
  minv = min(vals,pseudovals)
  maxv = max(vals,pseudovals)
  omin+(omax-omin)*(vals - minv)/(maxv-minv)
}
#####################################################################
#####################################################################
# set up "Real World" and "Hypothetical" column labels
axes.segdf <- data.frame()
axes.textdf <- data.frame()
x0=mean(c(rxmin,rxmax))
y0=l1max*1.03
axes.textdf<-rbind(axes.textdf,data.frame(x=x0,y=y0,label="Real-World column",col="black",pos=3))
x0=mean(c(hxmin,hxmax))
if( do.CI ){
  axes.textdf<-rbind(axes.textdf,data.frame(x=x0,y=y0,label="Approximate column",col="black",pos=3))
} else {
  axes.textdf<-rbind(axes.textdf,data.frame(x=x0,y=y0,label="Hypothetical column",col="black",pos=3))
}
# might want to add a horizontal line under those?

# set up x axis segments and xlabels
x0s=sprintf("%g",min(popxlim))
x1s=sprintf("%g",max(popxlim))
# first, the real-world column:
x0=mapto(min(popxlim),popxlim,rxmin,rxmax)
x1=mapto(max(popxlim),popxlim,rxmin,rxmax)
y0=mapto(           0,c(0,1),l1min,l1max)
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x0,y=y0,label=x0s,col="black",pos=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x1,y=y0,label=x1s,col="black",pos=1))
y0=mapto(           0,c(0,1),l2min,l2max)
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x0,y=y0,label=x0s,col="black",pos=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x1,y=y0,label=x1s,col="black",pos=1))
y0=mapto(           0,c(0,1),l3min,l3max)
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x0,y=y0,label=x0s,col="black",pos=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x1,y=y0,label=x1s,col="black",pos=1))
# and add some extra tick marks on the R3 cell
y0=mapto(           0,c(0,1),l3min,l3max)
y1=mapto(         0.03,c(0,1),l3min,l3max)
axes3.segdf <- data.frame()
axes3.textdf <- data.frame()
xvals = c(5,7,9)
for( nn in 1:length(xvals)){
  myx = xvals[nn]
  x.s=sprintf("%g",myx) # don't use x0s since we still need it later. That was a bug that I had to find!
  x0=mapto(myx,popxlim,rxmin,rxmax)
  x1=x0
  axes3.segdf <- rbind(axes3.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
  axes3.textdf<-rbind(axes3.textdf,data.frame(x=x0,y=y0,label=x.s,col="black",pos=1))
}
# now the other column:
x0=mapto(min(popxlim),popxlim,hxmin,hxmax)
x1=mapto(max(popxlim),popxlim,hxmin,hxmax)
y0=mapto(           0,c(0,1),l1min,l1max)
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x0,y=y0,label=x0s,col="black",pos=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x1,y=y0,label=x1s,col="black",pos=1))
y0=mapto(           0,c(0,1),l2min,l2max)
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x0,y=y0,label=x0s,col="black",pos=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x1,y=y0,label=x1s,col="black",pos=1))
y0=mapto(           0,c(0,1),l3min,l3max)
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x1,y=y0,label=x1s,col="black",pos=1))
axes.textdf<-rbind(axes.textdf,data.frame(x=x0,y=y0,label=x0s,col="black",pos=1))
# now set up the lines separating the six plots
# 1. the big vertical line 
x0=mean(c(rxmax,hxmin))
x1=x0
y0=l3min
y1=l1max
y0=0
y1=mean(c(1,l1max))
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
# the leftmost line on the outside
x0=0
x1=x0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
# the rightmost line on the outside
x0=1
x1=x0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))

# 2. the upper horizontal line within the grid
#x0=rxmin
#x1=hxmax
x0=0
x1=1
y0=mean(c(l1min,l2max))
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
# 3. the lower horizontal line within the grid
y0=mean(c(l2min,l3max))
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
# 4. the lowest line on the outside
y0=0
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
# 5. the highest line on the outside
y0=mean(c(1,l1max))
y1=y0
axes.segdf <- rbind(axes.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))

#####################################################################
# scale the thought bubble points to fit.
# The thought bubble points are all in the box [0,1]-by-[0,1]
# but they don't fill the box.
# These numbers below just come from adjusting by hand.
bubble.pdf=orig.bubble.pdf
x0=mapto(orig.bubble.pdf$x   ,c(0,0),rxmin,rxmax)
y0=mapto(orig.bubble.pdf$y   ,c(0,0),0+(l3min-0)*-0.5,l3max+(l2min-l3max)*0.5)
bubble.pdf$x = x0
bubble.pdf$y = y0

#####################################################################
#####################################################################
# Population plot, level 1
framenum=0
x=mapto(popdata,popxlim,rxmin,rxmax)
y=mapto(popy,NULL,l1min,l1max)
pop.pointdf <- data.frame(x,y,pch=utf8ToInt('?'),col="lightgrey",cex=0.5)

#add descriptive label and mean label and mean segment
x=rxmin
y=l1max
pop.textdf <- data.frame(x,y,label="Population",pos=4,col="black")
x0=mapto(popmean,popxlim,rxmin,rxmax)
x1=x0
y0=mapto(           0.8,c(0,1),l1min,l1max)
y1=mapto(           0,c(0,1),l1min,l1max)
pop.segdf <- data.frame(x0,y0,x1,y1,col="grey",lty="solid",lwd=1)
#tmp=sprintf("mu=%1.3g",popmean)
#tmp=expression("mu=???")
tmp="µ=???"
pop.textdf<-rbind(pop.textdf,data.frame(x=x0,y=y1,label=tmp,col="grey",pos=1))

s.df=rbind(axes.segdf,pop.segdf)
t.df=rbind(axes.textdf,pop.textdf)
mm="Simulation Approach to HT for a mean"
if( do.CI ){
  mm="Simulation Approach to CI for a mean"
}
render(pop.pointdf,textdf=t.df,segmentdf=s.df,fprefix="a",framenum=framenum,mymain=mm)
framenum=framenum+1

##############
# now level 2: the sample
sampn=16
# We could try running with different seeds/samples and pick one that shows
# sufficient evidence to reject H0.
# Actually it would be better to do that systematically, make a dotplot
# of the p-values, to see that it's uniform if H0 is actually true,
# and skewed with more values near 0 if H0 is false,
# but that would take a lot more work.
# We would want a 4th row or 3rd column, called "meta", for a dotplot
# of p-values, since it's like doing a meta-analysis (but not exactly).
# That would require adjusting the locations of the other plots, etc.

# at first I forgot to set the seed here, and generated some plots that
# I wrote into the materials, and that had a good p-value.
# Then later when I wanted to change the seed to get a different sample,
# I couldn't find a seed that gave as good of a result.
# So now we set it to have the ability to avoid setting the seed.
if(sampseed >= 0){  
  set.seed(sampseed)  
}

sampdata=sample(popdata,size=sampn,replace=F)
sampmean = mean(sampdata)

sampdata.1 <- round(sampdata,digits=rounddigits)
sampy=dotplot.coord(sampdata.1,sampdata)


x=mapto(sampdata,popxlim,rxmin,rxmax)
# scale the dotplot so the bottom row is a little above the x-axis,
# and the uppermost dot isn't very far away vertically,
# by pretending there's data at y=3.5*(largest y dotplot count)
# and also some data at 0.5*(smallest y dotplot count=1)
y=mapto(sampy,c(0.5,3.5*max(sampy)),l2min,l2max)
samp.pointdf <- data.frame(x,y,pch=1,col="black",cex=1)

#add descriptive label and mean label and mean segment
x=rxmin
y=l2max
tmp=sprintf("Sample: n=%d",sampn)
samp.textdf <- data.frame(x,y,label=tmp,pos=4,col="black")
x0=mapto(sampmean,popxlim,rxmin,rxmax)
x1=x0
y0=mapto(           0.8,c(0,1),l2min,l2max)
y1=mapto(           0,c(0,1),l2min,l2max)
y1.l2=y1 # save for use in level3
sample.segdf <- data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1)
#tmp=sprintf("xbar=%1.3g",sampmean)
tmp=sprintf("$\\bar{x}=%1.3g$",sampmean) # putting the $ after the number helps keep the TeX stuff from putting a space after the decimal point, like 6. 57
sample.textdf<-rbind(samp.textdf,data.frame(x=x0,y=y1,label=tmp,col="black",pos=1))


p.df=rbind(pop.pointdf,samp.pointdf)
s.df=rbind(axes.segdf,pop.segdf,sample.segdf)
t.df=rbind(axes.textdf,pop.textdf,sample.textdf)
render(p.df,textdf=t.df,segmentdf=s.df,fprefix="a",framenum=framenum,mymain="Take the real sample")
framenum=framenum+1

# add the sample data set to HTML body at this point

tmp=c(unlist(htmlb),"<p>the data values in the sample:<pre>",
      paste(sampdata,collapse="\n"),"</pre>")
assign("htmlb", tmp, envir = .GlobalEnv)

###########
# now level 3: the sampling distribution

#instead of guessing a y value for the observed mean,
# we'll generate a dotplot of other potential means (that we will mark
# with question marks), then get the smallest y value from that.
se.mult = 2 # might want to show more uncertainty about the mean
# than is actually justified, since in some sense, we don't know how
# much is justified until we do the randomization.
# At first I tried se.mul=3 but the team said it was too big,
# since the spread was then hard to tell from the spread of the sample.
fake.se = se.mult*popsd/sqrt(sampn)

nques=100

# randomly-generated data:
#set.seed(se.mult*100)
#tmpdata <- rnorm(n=30,mean=popmean,sd=fake.se)

# try perfectly-spaced normal data:
tmpdata <- qnorm(seq(from=1/nques,to=1-1/nques,length.out=nques))*fake.se+popmean
tmpdata.1 <- round(tmpdata,digits=rounddigits)
tmpy=dotplot.coord(tmpdata.1,tmpdata)

y=mapto(tmpy,c(0.9,1.5*max(tmpy)),l3min,l3max)

x=mapto(sampmean,popxlim,rxmin,rxmax)
y=min(y)
samplingdist.pointdf=data.frame(x,y,pch=2,col="magenta",cex=1) # pch2 is triangle


# add arrow
y0=l2min # deliberately crossing levels: using l2 information here in l3
y1=mean(c(l3min,l3max))
L=0.3*(l3max-l3min)
samplingdist.arrowdf=data.frame(x0=x,y0,x1=x,y1,length=L,col="magenta",lty="solid",lwd=1)

#add descriptive label 
samplingdist.textdf <- data.frame()
# will do this later, once we're asking how xbar varies:
#x=rxmin
#y=l3max
#tmp="Sampling Distribution of $\\bar{x}$?"
#samplingdist.textdf <- rbind(samplingdist.textdf,data.frame(x,y,label=tmp,pos=4,col="black"))


#instead of adding a mean segment and label, add a mu0 segment and label.
# or not:
showmu0r3 = F
x0=mapto(mu0,popxlim,rxmin,rxmax)
x1=x0
y0=mapto(           0.8,c(0,1),l3min,l3max)
y1=mapto(           0,c(0,1),l3min,l3max)
if( showmu0r3){
  samplingdist.segdf <- data.frame(x0,y0,x1,y1,col="black",lty="dotted",lwd=2)
  #tmp=sprintf("µ0=%1.3g",mu0)
  tmp=sprintf("$µ_0$=%1.3g",mu0)
}else{ # use a zero-width line and no text, so we don't show mu0
  # and just to be safe, use y0 as y1
  samplingdist.segdf <- data.frame(x0,y0,x1,y1=y0,col="black",lty="dotted",lwd=0)
  #tmp=sprintf("µ0=%1.3g",mu0)
  tmp=sprintf("")
}
samplingdist.textdf<-rbind(samplingdist.textdf,data.frame(x=x0,y=y1,label=tmp,col="black",pos=1))


# "permanently" add the extra tick marks and labels to the r3 axis,
# so we don't have to specify it each time after this:
axes.segdf <- rbind(axes.segdf, axes3.segdf)
axes.textdf <- rbind(axes.textdf, axes3.textdf)

p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf)
s.df=rbind(axes.segdf,pop.segdf,sample.segdf)
t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf[1,])

# render it with the arrow, and then again without, then with the mu0 bar
# (of course the mu0 bar might have been set to blank, but to avoid
# changing this code we'll render whatever it calls for, blank or not.)
render(p.df,textdf=t.df,segmentdf=s.df,arrowdf=samplingdist.arrowdf,fprefix="a",framenum=framenum,mymain="Record the mean")
framenum=framenum+1

# add a little explanation to the HTML body at this point
tmp=c(unlist(htmlb),"<p>Using magenta because both \"mean\" and \"magenta\" start with \"m\".",
      "<p>Also, using an upward-pointing triangle because a mean is like a fulcrum/balance point.")
assign("htmlb", tmp, envir = .GlobalEnv)


# render again,
#include the bar for mu0 (whether it ended up blank, or not, above.)
s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf)
t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf)
# my first title for this was:
#me=expression(bar(x)~"isn't exactly"~μ[0]*"--surprising?") #the * is like ~ but doesn't produce a space.
# but MW suggested something more like
#me=expression("Is"~bar(x)~"too far from"~μ[0]~"for"~μ[0]~"to be plausible?") #the * is like ~ but doesn't produce a space.
tmp=sprintf("Is $\\bar{x}$ too far from $μ_0$=%1.0g for $μ_0$ to be plausible? ",mu0)
plaintext=sprintf("Is xbar too far from μ_0=%1.0g for μ_0 to be plausible? ",mu0)
me=TeX(tmp)

if( do.CI ){
  tmp=sprintf("How far might $\\bar{x}$ be from μ?")
  plaintext=sprintf("How far might xbar be from μ?")
  me=TeX(tmp)
}

render(p.df,textdf=t.df,segmentdf=s.df,fprefix="a",framenum=framenum,mymain=plaintext,main.expr=me)
framenum=framenum+1

# now put some question marks around it to indicate that we are uncertain
# about how much sampling variability there is.

# but, before plotting, delete any questionmarks that will be
# too close to the triangle showing xbar from the sample:
del.these=(abs(tmpdata-sampmean)<popsd*0.25) & (abs(tmpy-min(tmpy))<=1)
tmpdata=tmpdata[!del.these]
tmpdata.1=tmpdata.1[!del.these]
tmpy=tmpy[!del.these]

# also, trim down the number of question-marks to plot,
# so we can see that they are distinct question marks.
del.these=runif(n=length(tmpdata)) < 0.4 # delete 40% of them
tmpdata=tmpdata[!del.these]
tmpdata.1=tmpdata.1[!del.these]
tmpy=tmpy[!del.these]


x=mapto(tmpdata,popxlim,rxmin,rxmax)
y=mapto(tmpy,c(0.9,1.5*max(tmpy)),l3min,l3max)
tmp.pointdf <- data.frame(x,y,pch=utf8ToInt('?'),col="magenta",cex=0.5)
# had to convert the '?' to an ascii code, with utf8ToInt
# so the data frame column "pch"
# wouldn't switch from class=int to class=char, because if it did,
# then the 1's and 2's in it already would plot strangely.

# and "permanently" add the thought-bubble points to samplingdist.pointdf
samplingdist.pointdf=rbind(samplingdist.pointdf,bubble.pdf)

x=rxmin
y=l3max
tmp="Sampling Distribution of $\\bar{x}$?"
samplingdist.textdf <- rbind(samplingdist.textdf,data.frame(x,y,label=tmp,pos=4,col="black"))

t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf)

p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf)
me=expression("How much might"~bar(x)~"vary due to random sampling alone?")
plaintext="How much might xbar vary due to random sampling alone?"
render(p.df,textdf=t.df,segmentdf=s.df,fprefix="a",framenum=framenum,mymain=plaintext,main.expr=me)
framenum=framenum+1

# add a little explanation to the HTML body at this point
if( do.CI ){
  tmp=c(unlist(htmlb),"<p>We would like to take repeated random samples (all of the same size) from the population, but we can't because it would take more time/money.",
        "<p>It would be nice if we had a dataset similar to the population that we could use a computer to randomly sample from, keeping the same sample size.")
}else {
  tmp=c(unlist(htmlb),"<p>We would like to take repeated random samples (all of the same size) from the population, but we can't because it would take more time/money.",
        "<p>It would be nice if we had a dataset similar to the population (but with mean μ0) that we could use a computer to randomly sample from, keeping the same sample size.")
}
assign("htmlb", tmp, envir = .GlobalEnv)


# maybe render it again without the question marks
#p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf)



######################################################################
########################################################################
# now the Hypothesis column

# first have an arrow showing the sample copied over to cell H1,
# from sampmean to sampmean
x0=mapto(sampmean,popxlim,rxmin,rxmax)
x1=mapto(sampmean,popxlim,hxmin,hxmax)
y0=mapto(           0,c(0,1),l2min,l2max)
y1=mapto(           0,c(0,1),l1min,l1max)
L=0.5*(l1max-l1min)
h1.arrowdf=data.frame(x0,y0,x1,y1,length=L,col="black",lty="solid",lwd=1)

s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf)
t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf)
p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf)
render(p.df,textdf=t.df,segmentdf=s.df,arrowdf=h1.arrowdf,fprefix="a",framenum=framenum,mymain="The sample can serve as an approx. population,")
framenum=framenum+1

# now show the sample data in cell H1, before shifting.
# using grey for dots now:
newpopdata=sampdata
newpopmean=mean(newpopdata)
newpopdata.1 <- round(newpopdata,digits=rounddigits)
newpopy=dotplot.coord(newpopdata.1,newpopdata)
x=mapto(newpopdata,popxlim,hxmin,hxmax)
# scale the dotplot so the bottom row is a little above the x-axis,
# and the uppermost dot isn't very far away vertically,
# by pretending there's data at y=3.5*(largest y dotplot count)
# and also some data at 0.5*(smallest y dotplot count=1)
y=mapto(newpopy,c(0.5,3.5*max(newpopy)),l1min,l1max)
newpop.pointdf <- data.frame(x,y,pch=1,col="darkgrey",cex=1)
x=hxmin
y=l1max
h1.textdf <- data.frame(x,y,label="Approx./ Hyp. Pop.",pos=4,col="black")
# TeX() will put a space after the . in Approx. so we're putting a space
# after the / to balance things out.

s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf)
t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf)
p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf)
render(p.df,textdf=t.df,segmentdf=s.df,arrowdf=h1.arrowdf,fprefix="a",framenum=framenum,mymain="so copy it.")
framenum=framenum+1

#add a bar for the mean, and a bar for mu0
x0=mapto(sampmean,popxlim,hxmin,hxmax)
x1=x0
y0=mapto(           0.8,c(0,1),l1min,l1max)# using 0.8 instead of 1
# to try to avoid running into text above it.
y1=mapto(           0,c(0,1),l1min,l1max)
h1.segdf <- data.frame(x0,y0,x1,y1,col="darkgrey",lty="solid",lwd=1)
#tmp=sprintf("xbar=%1.3g",sampmean)
#h1.textdf<-rbind(samp.textdf,data.frame(x=x0,y=y1,label=tmp,col="black",pos=1))

if( ! do.CI ){
  #for mu0
  x0=mapto(mu0,popxlim,hxmin,hxmax)
  x1=x0
  #can use the same y0,y1 as above.
  #using width>1 so when they superimpose we can still see both dotted and solid
  h1.segdf <- rbind(h1.segdf,data.frame(x0,y0,x1,y1,col="black",lty="dotted",lwd=2))
  #tmp=sprintf("µ0=%1.3g",mu0)
  tmp=sprintf("$µ_0$=%1.3g",mu0)
  h1.textdf<-rbind(h1.textdf,data.frame(x=x0,y=y1,label=tmp,col="black",pos=1))
  s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf)
  t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf)
  p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf)
  me=expression("But, its mean doesn't match"~μ[0]*",")
  render(p.df,textdf=t.df,segmentdf=s.df,arrowdf=h1.arrowdf,fprefix="a",framenum=framenum,mymain="But, its mean doesn't match μ0,",main.expr=me)
  framenum=framenum+1
  
  # now add an arrow showing that we'll shift the mean of the approx.pop.
  # to match mu0:
  #(would it be better to have an arrow on _each data point_?)
  #x0=mapto(sampmean,popxlim,hxmin,hxmax) # just an arrow on the mean
  #y0=mapto(           1,c(0,1),l1min,l1max)
  #y1=mapto(           1,c(0,1),l1min,l1max)
  
  # don't keep plotting the arrow showing the copying from R2 to H1:
  h1.arrowdf <- data.frame()
  # the arrow showing the mean moving happens because we're throwing
  # sampmean and mu0 into the x0 and x1 lists:
  x0=mapto(c(sampmean,newpopdata               ),popxlim,hxmin,hxmax)
  x1=mapto(c(mu0     ,newpopdata-newpopmean+mu0),popxlim,hxmin,hxmax)
  # scale the dotplot so the bottom row is a little above the x-axis,
  # and the uppermost dot isn't very far away vertically,
  # by pretending there's data at y=3.5*(largest y dotplot count)
  # and also some data at 0.5*(smallest y dotplot count=1)
  meanarrowy = l1min + (l1max-l1min)*0.8
  y0=c(meanarrowy,mapto(newpopy,c(0.5,3.5*max(newpopy)),l1min,l1max))
  y1=y0
  L=0.3*(l1max-l1min)
  #L=0.1*(l1max-l1min) # use small arrows for this? But turns out you can't see the small arrows well.
  h1.arrowdf<-rbind(h1.arrowdf,data.frame(x0,y0,x1,y1,length=L,col="black",lty="solid",lwd=1))
  s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf)
  t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf)
  p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf)
  render(p.df,textdf=t.df,segmentdf=s.df,arrowdf=h1.arrowdf,fprefix="a",framenum=framenum,mymain="so shift it.")
  framenum=framenum+1
  
  #now actually move the approx.pop.
  #We'll move the x values but not regenerate the y values,
  #because we don't want to confuse things.
  newpopdata=sampdata - mean(sampdata)+mu0
  newpopdata.1 =sampdata.1 - mean(sampdata)+mu0
  newpopmean=mean(newpopdata)
  
  x=mapto(newpopdata,popxlim,hxmin,hxmax)
  # scale the dotplot so the bottom row is a little above the x-axis,
  # and the uppermost dot isn't very far away vertically,
  # by pretending there's data at y=3.5*(largest y dotplot count)
  # and also some data at 0.5*(smallest y dotplot count=1)
  y=mapto(newpopy,c(0.5,3.5*max(sampy)),l1min,l1max)
  newpop.pointdf <- data.frame(x,y,pch=1,col="darkgrey",cex=1)
  
  # and make a new mean bar and mu0 bar:
  x0=mapto(newpopmean,popxlim,hxmin,hxmax)
  x1=x0
  y0=mapto(           0.8,c(0,1),l1min,l1max)
  y1=mapto(           0  ,c(0,1),l1min,l1max)
  h1.segdf <- data.frame(x0,y0,x1,y1,col="darkgrey",lty="solid",lwd=1)
  # and mu0 bar (easier than saving the old one)
  x0=mapto(mu0,popxlim,hxmin,hxmax)
  x1=x0
  #can use the same y0,y1 as above.
  #using width 3 so when they superimpose we can still see both dotted and solid
  h1.segdf <- rbind(h1.segdf,data.frame(x0,y0,x1,y1,col="black",lty="dotted",lwd=2))
  
  s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf)
  t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf)
  p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf)
  #no arrows this time:
  me=expression("Approx./Hyp.pop. with mean="*μ[0])
  render(p.df,textdf=t.df,segmentdf=s.df,fprefix="a",framenum=framenum,mymain="Approx./Hyp. pop. with mean=μ0",main.expr=me)
  framenum=framenum+1
} else { # if ! do.CI, else just copy stuff.
  newpopdata=sampdata 
  newpopdata.1 =sampdata.1 
  newpopmean=mean(newpopdata)
}
################
# randomization sample

# Will do a few randomizations slowly,
# then will do 1000 (?) for about 5 seconds, so
# (1000/5)/30=7 randomizations or so per frame.
# Then will show xbar being copied from cell R2 to H3,
# and highlight a tail to show the P-value.

randomizdistdata<-c() #just make a place to store it
randomizdist.pointdf <- data.frame()
randomizdist.textdf = NULL

few.n = 5
for( nn in 1:few.n){
  # get new random sample from newpop (not original pop)
  myseed=nn
  set.seed(myseed)
  rsampdata=sample(newpopdata,size=sampn,replace=T)
  rsampmean = mean(rsampdata)
  # and store it
  randomizdistdata<-c(randomizdistdata,rsampmean)
  
  rsampdata.1 <- round(rsampdata,digits=rounddigits)
  rsampy=dotplot.coord(rsampdata.1,rsampdata)
  
  x=mapto(rsampdata,popxlim,hxmin,hxmax)
  y=mapto(rsampy,c(0.5,1.5*max(rsampy)),l2min,l2max)
  rsamp.pointdf <- data.frame(x,y,pch=1,col="black",cex=1)
  
  #add descriptive label and mean label and mean segment
  x=hxmin
  y=l2max
  tmp=sprintf("Simulation Sample: n=%d",sampn)
  rsamp.textdf <- data.frame(x,y,label=tmp,pos=4,col="black")
  tmp=sprintf(" repetition# %d",nn)
  y=l2max-(l2max-l2min)*0.2
  rsamp.textdf <- rbind(rsamp.textdf,data.frame(x,y,label=tmp,pos=4,col="black"))
  
  x0=mapto(rsampmean,popxlim,hxmin,hxmax)
  x1=x0
  y0=mapto(           0.8,c(0,1),l2min,l2max)
  y1=mapto(           0,c(0,1),l2min,l2max)
  y1.l2=y1 # save for use in level3
  rsamp.segdf <- data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1)
  # commenting out this "xbar" label because not sure what to call it
  # to keep it distinct from the original sample's xbar.
  # "xbar_randomiz" would make sense but it's too long
  #tmp=sprintf("xbar=%1.3g",sampmean)
  #rsample.textdf<-rbind(samp.textdf,data.frame(x=x0,y=y1,label=tmp,col="black",pos=1))
  s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf,rsamp.segdf)
  t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf,rsamp.textdf,randomizdist.textdf)
  p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf,rsamp.pointdf,randomizdist.pointdf)
  render(p.df,textdf=t.df,segmentdf=s.df,fprefix="b",framenum=framenum,mymain="Sample (with replacement)")
  framenum=framenum+1
  
  # now update level3
  randomizdistdata.1 <- round(randomizdistdata,digits=rounddigits)
  rzy=dotplot.coord(randomizdistdata.1,randomizdistdata)
  
  x=mapto(randomizdistdata,popxlim,hxmin,hxmax)
  y=mapto(rzy,c(0.9,1.5*max(tmpy)),l3min,l3max)
  
  randomizdist.pointdf=data.frame(x,y,pch=2,col="magenta",cex=0.5) # pch2 is triangle
  
  # add arrow
  x=mapto(rsampmean,popxlim,hxmin,hxmax)
  y0=l2min # deliberately crossing levels: using l2 information here in l3
  y1=mean(c(l3min,l3max))
  L=0.2*(l3max-l3min)
  randomizdist.arrowdf=data.frame(x0=x,y0,x1=x,y1,length=L,col="magenta",lty="solid",lwd=1)
  
  #add descriptive label 
  x=hxmin
  y=l3max
  tmp="Simulation Distribution of $\\bar{x}$,"
  randomizdist.textdf <- data.frame(x,y,label=tmp,pos=4,col="black")
  tmp=sprintf(" repetitions=%d",nn)
  y=l3max-(l3max-l3min)*0.25
  randomizdist.textdf <- rbind(randomizdist.textdf,data.frame(x,y,label=tmp,pos=4,col="black"))
  
  s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf,rsamp.segdf)
  t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf,rsamp.textdf,randomizdist.textdf)
  p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf,rsamp.pointdf,randomizdist.pointdf)
  render(p.df,textdf=t.df,segmentdf=s.df,arrowdf=randomizdist.arrowdf,fprefix="b",framenum=framenum,mymain="Record mean")
  framenum=framenum+1
  
} # for( nn in 1:few.n){

# now do rapid sampling:
samps.per.frame=10
for( nn in (few.n+1):1000){
  # get new random sample from newpop (not original pop)
  myseed=nn
  set.seed(myseed)
  rsampdata=sample(newpopdata,size=sampn,replace=T)
  rsampmean = mean(rsampdata)
  # and store it
  randomizdistdata<-c(randomizdistdata,rsampmean)
  
  if( ( nn %% samps.per.frame )==0 ){ #then output this frame
    print(nn)
    rsampdata.1 <- round(rsampdata,digits=rounddigits)
    rsampy=dotplot.coord(rsampdata.1,rsampdata)
    
    x=mapto(rsampdata,popxlim,hxmin,hxmax)
    y=mapto(rsampy,c(0.9,1.5*max(rsampy)),l2min,l2max)
    rsamp.pointdf <- data.frame(x,y,pch=1,col="black",cex=1)
    
    #add descriptive label and mean label and mean segment
    x=hxmin
    y=l2max
    tmp=sprintf("Simulation Sample: n=%d",sampn)
    rsamp.textdf <- data.frame(x,y,label=tmp,pos=4,col="black")
    tmp=sprintf(" repetition# %d",nn)
    y=l2max-(l2max-l2min)*0.2
    rsamp.textdf <- rbind(rsamp.textdf,data.frame(x,y,label=tmp,pos=4,col="black"))
    
    x0=mapto(rsampmean,popxlim,hxmin,hxmax)
    x1=x0
    y0=mapto(           0.8,c(0,1),l2min,l2max)
    y1=mapto(           0,c(0,1),l2min,l2max)
    y1.l2=y1 # save for use in level3
    rsamp.segdf <- data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1)
    # commenting out this "xbar" label because not sure what to call it
    # to keep it distinct from the original sample's xbar.
    # "xbar_randomiz" would make sense but it's too long
    #tmp=sprintf("xbar=%1.3g",sampmean)
    #rsample.textdf<-rbind(samp.textdf,data.frame(x=x0,y=y1,label=tmp,col="black",pos=1))
    # don't render at this point, because we will update the randomiz. dist too,
    # since we are doing rapid frames.
    #s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf,rsamp.segdf)
    #t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf,rsamp.textdf,randomizdist.textdf)
    #p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf,rsamp.pointdf,randomizdist.pointdf)
    #render(p.df,textdf=t.df,segmentdf=s.df,fprefix="c",framenum=framenum,mymain="Sample (with replacement)")
    #framenum=framenum+1
    
    # now update level3
    randomizdistdata.1 <- round(randomizdistdata,digits=rounddigits)
    rzy=dotplot.coord(randomizdistdata.1,randomizdistdata)
    
    x=mapto(randomizdistdata,popxlim,hxmin,hxmax)
    y=mapto(rzy,c(0.9,1.5*max(tmpy)),l3min,l3max)
    
    randomizdist.pointdf=data.frame(x,y,pch=2,col="magenta",cex=0.5) # pch2 is triangle
    
    # add arrow
    x=mapto(rsampmean,popxlim,hxmin,hxmax)
    y0=l2min # deliberately crossing levels: using l2 information here in l3
    y1=mean(c(l3min,l3max))
    L=0.2*(l3max-l3min)
    randomizdist.arrowdf=data.frame(x0=x,y0,x1=x,y1,length=L,col="magenta",lty="solid",lwd=1)
    
    #add descriptive label 
    x=hxmin
    y=l3max
    tmp="Simulation Distribution of $\\bar{x}$,"
    randomizdist.textdf <- data.frame(x,y,label=tmp,pos=4,col="black")
    tmp=sprintf(" repetitions=%d",nn)
    y=l3max-(l3max-l3min)*0.2
    randomizdist.textdf <- rbind(randomizdist.textdf,data.frame(x,y,label=tmp,pos=4,col="black"))
    
    s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf,rsamp.segdf)
    t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf,rsamp.textdf,randomizdist.textdf)
    p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf,rsamp.pointdf,randomizdist.pointdf)
    #render(p.df,textdf=t.df,segmentdf=s.df,arrowdf=randomizdist.arrowdf,fprefix="b",framenum=framenum,mymain="Record mean")
    render(p.df,textdf=t.df,segmentdf=s.df,fprefix="c",framenum=framenum,mymain="Repeat!")
    framenum=framenum+1
  }
} # for( nn in (few.n+1):1000){

################################################
###############################################
# Now that all the randomization is done, compute the p-value
# by copying original xbar over to the H3 plot and highlighting the tail.

# First, a new caption for the same plot as the most recent frame,
# but take out the resampled xbar segment because it will be confusing later.
s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf)

me=expression("Suppose null is true. Is original"~bar(x)~"plausible?")
mm="Suppose null is true. Is original xbar plausible?"
if( do.CI ){
  tmp=sprintf("What interval contains $\\bar{x}$, %g%% of the time?",100*confidence)
  me=TeX(tmp)
  mm=sprintf("What interval contains xbar, %g%% of the time?",100*confidence)
}
render(p.df,textdf=t.df,segmentdf=s.df,fprefix="d",framenum=framenum,mymain=mm,main.expr=me)
framenum=framenum+1

if( ! do.CI ){
  # Add an arrow showing copying original xbar from R2 to H3,
  # and copy the xbar segment.
  x0=mapto(sampmean,popxlim,rxmin,rxmax)
  x1=mapto(sampmean,popxlim,hxmin,hxmax)
  y0=mapto(           0,c(0,1),l2min,l2max)
  y1=mapto(           0,c(0,1),l3min,l3max)
  L=0.5*(l3max-l3min)
  h3.arrowdf=data.frame(x0,y0,x1,y1,length=L,col="black",lty="solid",lwd=1)
  
  # xbar segment
  x0=mapto(sampmean,popxlim,hxmin,hxmax)
  x1=x0
  y0=mapto(           0,c(0,1),l3min,l3max)
  y1=mapto(           0.8,c(0,1),l3min,l3max)
  h3.segdf=data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1)
  #tmp=sprintf("xbar=%1.3g",sampmean)
  tmp=sprintf("$\\bar{x}=%1.3g$",sampmean) # putting the $ after the number helps keep the TeX stuff from putting a space after the decimal point, like 6. 57
  randomizdist.textdf<-rbind(randomizdist.textdf,data.frame(x=x0,y=y0,label=tmp,col="black",pos=1))
  
  # compute p-value:
  # find % on each side of xbar, take smaller value. That's the one-sided p-value.
  nreps<-length(randomizdistdata)
  leftcount <- sum(randomizdistdata<=sampmean)
  leftp <- leftcount/nreps
  count.1sided <- min(leftcount,nreps-leftcount)
  p.1sided <- min(leftp,1-leftp)
  #now decide which side to highlight, and highlight it,
  # by turning the tail symbols to red,
  # and turning the non-tail symbols to something small.
  newpch=randomizdist.pointdf$pch
  newcol=randomizdist.pointdf$col
  
  if( leftp < 1-leftp){
    #  newpch[randomizdistdata>sampmean]=46 # pch="."
    newcol[randomizdistdata<sampmean]="red"
  }else{
    #  newpch[randomizdistdata<sampmean]=46 # pch="."
    newcol[randomizdistdata>sampmean]="red"
  }
  randomizdist.pointdf$pch = newpch
  randomizdist.pointdf$col = newcol
  #tmpmain=sprintf("1-sided p-value=%d/%d=%g",count.1sided,nreps,p.1sided)
  tmpmain=sprintf("1-sided p-value=%d/%d=%g",count.1sided,nreps,p.1sided)
  me=TeX(sprintf("1-sided p-value=%d/%d=$%g$",count.1sided,nreps,p.1sided))
  # using $ $ to protect a decimal point from getting a space after it.
  
  #again, not showing the resampled xbar segment
  s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf,h3.segdf)
  t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf,rsamp.textdf,randomizdist.textdf)
  p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf,rsamp.pointdf,randomizdist.pointdf)
  render(p.df,textdf=t.df,segmentdf=s.df,arrowdf=h3.arrowdf,fprefix="d",framenum=framenum,mymain=tmpmain,main.expr=me)
  framenum=framenum+1
}else{
  # do.CI is true
  
  # first find the tail cutoffs
  confidence = 0.95
  tailsize = (1-confidence)/2
  myci = quantile( randomizdistdata , c(tailsize, confidence+tailsize))
  
  h3.segdf=data.frame()
  
  # lower segment
  x0=mapto(myci[1],popxlim,hxmin,hxmax)
  x1=x0
  y0=mapto(           0,c(0,1),l3min,l3max)
  y1=mapto(           0.8,c(0,1),l3min,l3max)
  h3.segdf=rbind(h3.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
  #tmp=sprintf("xbar=%1.3g",sampmean)
  #tmp=sprintf("$\\bar{x}$=%1.3g",sampmean)
  tmp=sprintf("$%1.3g$",myci[1])
  y0=l3min + (l3max-l3min)*+0.1
  randomizdist.textdf<-rbind(randomizdist.textdf,data.frame(x=x0,y=y0,label=tmp,col="black",pos=1))
  # upper segment
  x0=mapto(myci[2],popxlim,hxmin,hxmax)
  x1=x0
  y0=mapto(           0,c(0,1),l3min,l3max)
  y1=mapto(           0.8,c(0,1),l3min,l3max)
  h3.segdf=rbind(h3.segdf,data.frame(x0,y0,x1,y1,col="black",lty="solid",lwd=1))
  #tmp=sprintf("xbar=%1.3g",sampmean)
  #tmp=sprintf("$\\bar{x}$=%1.3g",sampmean)
  tmp=sprintf("$%1.3g$",myci[2])
  y0=l3min + (l3max-l3min)*-0.1
  randomizdist.textdf<-rbind(randomizdist.textdf,data.frame(x=x0,y=y0,label=tmp,col="black",pos=1))
  
  
  #now highlight tails
  # by turning the tail symbols to red,
  # and turning the symbols to something small.
  newpch=randomizdist.pointdf$pch
  newcol=randomizdist.pointdf$col
  
  #  newpch[randomizdistdata<myci[1]]=46 # pch="."
  #  newpch[randomizdistdata>myci[2]]=46 # pch="."
  newcol[randomizdistdata<myci[1]]="red"
  newcol[randomizdistdata>myci[2]]="red"
  
  randomizdist.pointdf$pch = newpch
  randomizdist.pointdf$col = newcol
  tmpmain=sprintf("%g%% CI: %1.3g to %1.3g",100*confidence,myci[1],myci[2])
  me=TeX(sprintf("%g%% CI: $%1.3g$ to $%1.3g$",100*confidence,myci[1],myci[2]))
  
  
  #again, not showing the resampled xbar segment
  s.df=rbind(axes.segdf,pop.segdf,sample.segdf,samplingdist.segdf,h1.segdf,h3.segdf)
  t.df=rbind(axes.textdf,pop.textdf,sample.textdf,samplingdist.textdf,h1.textdf,rsamp.textdf,randomizdist.textdf)
  p.df=rbind(pop.pointdf,samp.pointdf,samplingdist.pointdf,tmp.pointdf,newpop.pointdf,rsamp.pointdf,randomizdist.pointdf)
  # deliberately leaving out h3.arrowdf
  render(p.df,textdf=t.df,segmentdf=s.df,fprefix="d",framenum=framenum,mymain=tmpmain,main.expr=me)
  framenum=framenum+1
  
} # if do.CI


################################################
###############################################
# Write out the html

#put in the animated gif
gifname <- sprintf("framework_%s.gif",mymethod)
imggif <- sprintf("<img src=\"%s\" alt=\"%s\">",gifname,gifname) 

# put it all together:
htmlall=c("<html>","<body>",imggif,"(it can take 15 seconds to start animating)",
          "<ol>",htmli,"</ol>",htmlb,
          "<p><a href=\"./\">To find the R code that generated this, look in the folder by clicking here.</a>",
          "</body>","</html>")
h.df=data.frame(htmlall)
# and write it out:
hfname <- sprintf("framework_%s.html",mymethod)
write.table(h.df,file=hfname,quote=F,row.names=F,col.names=F)

# would be best to put the R code at the end of the HTML file;
# do something like: 
# echo "<pre>" >> framework_*.html
# cat mtep_framework_anim_2col_v05.R >> framework_*.html


################################################
###############################################

# from: https://www.r-bloggers.com/animated-plots-with-r/
# then run this from a Unix- or Windows-like command line:
# convert *.png -delay 3 -loop 0 binom.gif
# or in our case
# convert sd_unbiased_anim_frame*.png -delay 20 -loop 0 sd_unbiased_anim.gif
# according to https://www.imagemagick.org/discourse-server/viewtopic.php?t=14739
# the delay value is 1/100ths of a second, so frame rate is 100/delay
# I'm trying delay of 20.
# Also, different delays for different frames:
# https://stackoverflow.com/questions/40191000/imagemagick-convert-command-set-delay-time-for-the-last-frame
# "convert -delay 40 <N-1 images> -delay 300 <Nth image> result.gif"
# also try: -layers OptimizeTransparency
# "tells ImageMagick to replace portions of each frame that are identical to the corresponding parts of the preceding frame with transparency, saving on file size"
# we'll try:
# convert -delay 500 framework_anim_frame_a*.png -delay 100 framework_anim_frame_b*.png -delay 3 framework_anim_frame_c*.png -delay 500 framework_anim_frame_d*.png framework_anim_1htm.gif
mycommand=sprintf("convert -delay 500 framework_%s_frame_a*.png -delay 100 framework_%s_frame_b*.png -delay 3 framework_%s_frame_c*.png -delay 500 framework_%s_frame_d*.png framework_%s.gif",mymethod,mymethod,mymethod,mymethod,mymethod)
print(mycommand)